/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repasoprueba2;

import Vista.Vista;

/**
 *
 * @author Rayson
 */
public class RepasoPrueba2 {

    public static void main(String[] args) {
        Vista vista=new Vista();
        vista.setVisible(true);
    }
}
